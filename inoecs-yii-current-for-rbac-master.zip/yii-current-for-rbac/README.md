# yii current for rbac 这是noecs的通用权限系统。
> 使用Yii框架内置rbac权限管理。
> 更简洁的代码，有利于二次开发。
> 通用性强，使用方便。

###### 作者名称：noecs
###### 作者网址：https://soera.cn
###### 作者邮箱：noecs@qq.com

### 安装说明
1.clone或者下载zip到服务器。
2.创建虚拟主机，目录指向本程序的 /backend/web/。
3.导入程序的数据库。
4.项目根目录下运行composer install（安装yii2类库）（首次安装项目必须运行）
5.项目初始化：linux下 php init;windows下运行init.bat文件。（注意：Development是开发版本，Production为生产环境）（首次安装必须运行）
6.配置/common/config/main-local.php的数据库链接。
（注意：如果是lnmp环境，需要配置.user.ini文件，添加项目根目录权限即可）
7.访问域名，账号admin,密码admin。

### 使用技巧
1.如果你在本地开发，服务器上测试，建议使用git。
2.第一次部署时需要运行composer安装类库和init初始化，.gitignore文件会帮你自动将线上线下配置文件区分开来。之后不需要再次配置。
3.如果需要添加组件等等修改公共配置文件的地方，建议放入main.php文件内，因为main-local将不纳入版本控制。



#### 更新2017年11月20日11:02:21
```
1.将之前类库和项目区分开来，类库将不纳入版本控制
2.重点bug修复，加入对子角色的控制。
```