/*
Navicat MySQL Data Transfer

Source Server         : 本地
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : npay

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2017-11-20 11:24:17
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for auth_assignment
-- ----------------------------
DROP TABLE IF EXISTS `auth_assignment`;
CREATE TABLE `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of auth_assignment
-- ----------------------------
INSERT INTO `auth_assignment` VALUES ('admin', '1', '1508640274');

-- ----------------------------
-- Table structure for auth_item
-- ----------------------------
DROP TABLE IF EXISTS `auth_item`;
CREATE TABLE `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` blob,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of auth_item
-- ----------------------------
INSERT INTO `auth_item` VALUES ('admin', '1', '管理员', null, null, '1508640011', '1508640011');
INSERT INTO `auth_item` VALUES ('rbac/assignitem', '2', '权限系统/分配权限', null, null, '1508640254', '1508640467');
INSERT INTO `auth_item` VALUES ('rbac/create', '2', '权限系统/添加角色', null, null, '1508640711', '1508640711');
INSERT INTO `auth_item` VALUES ('rbac/createitem', '2', '权限系统/添加权限', null, null, '1508640344', '1508640344');
INSERT INTO `auth_item` VALUES ('rbac/delete', '2', '权限系统/删除角色', null, null, '1508640774', '1508640774');
INSERT INTO `auth_item` VALUES ('rbac/deleteitem', '2', '权限系统/删除节点', null, null, '1508640563', '1508640580');
INSERT INTO `auth_item` VALUES ('rbac/index', '2', '权限系统/角色列表', null, null, '1508640675', '1508640675');
INSERT INTO `auth_item` VALUES ('rbac/update', '2', '权限系统/修改角色', null, null, '1508640742', '1508640742');
INSERT INTO `auth_item` VALUES ('rbac/updateitem', '2', '权限系统/修改节点', null, null, '1508640538', '1508640538');
INSERT INTO `auth_item` VALUES ('site/index', '2', '后台首页/后台首页', null, null, '1508738152', '1508738152');
INSERT INTO `auth_item` VALUES ('user/create', '2', '管理员系统/添加管理员', null, null, '1508640083', '1508640083');
INSERT INTO `auth_item` VALUES ('user/index', '2', '管理员系统/管理员列表', null, null, '1508640105', '1508640105');
INSERT INTO `auth_item` VALUES ('user/myinfo', '2', '管理员系统/修改我的信息', null, null, '1508640963', '1508640963');
INSERT INTO `auth_item` VALUES ('user/mypassword', '2', '管理员系统/修改我的密码', null, null, '1508640993', '1508640993');
INSERT INTO `auth_item` VALUES ('user/update', '2', '管理员系统/修改管理员', null, null, '1508738242', '1508738242');
INSERT INTO `auth_item` VALUES ('user/upuserpass', '2', '管理员系统/修改管理员密码', null, null, '1508640890', '1508640890');

-- ----------------------------
-- Table structure for auth_item_child
-- ----------------------------
DROP TABLE IF EXISTS `auth_item_child`;
CREATE TABLE `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of auth_item_child
-- ----------------------------
INSERT INTO `auth_item_child` VALUES ('admin', 'rbac/assignitem');
INSERT INTO `auth_item_child` VALUES ('admin', 'rbac/create');
INSERT INTO `auth_item_child` VALUES ('admin', 'rbac/createitem');
INSERT INTO `auth_item_child` VALUES ('admin', 'rbac/delete');
INSERT INTO `auth_item_child` VALUES ('admin', 'rbac/deleteitem');
INSERT INTO `auth_item_child` VALUES ('admin', 'rbac/index');
INSERT INTO `auth_item_child` VALUES ('admin', 'rbac/update');
INSERT INTO `auth_item_child` VALUES ('admin', 'rbac/updateitem');
INSERT INTO `auth_item_child` VALUES ('admin', 'site/index');
INSERT INTO `auth_item_child` VALUES ('admin', 'user/create');
INSERT INTO `auth_item_child` VALUES ('admin', 'user/index');
INSERT INTO `auth_item_child` VALUES ('admin', 'user/myinfo');
INSERT INTO `auth_item_child` VALUES ('admin', 'user/mypassword');
INSERT INTO `auth_item_child` VALUES ('admin', 'user/update');
INSERT INTO `auth_item_child` VALUES ('admin', 'user/upuserpass');

-- ----------------------------
-- Table structure for auth_rule
-- ----------------------------
DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` blob,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of auth_rule
-- ----------------------------

-- ----------------------------
-- Table structure for loginlog
-- ----------------------------
DROP TABLE IF EXISTS `loginlog`;
CREATE TABLE `loginlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '登录记录表',
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '用户登录IP',
  `created_time` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of loginlog
-- ----------------------------
INSERT INTO `loginlog` VALUES ('8', '1', '127.0.0.1', '1508738054');
INSERT INTO `loginlog` VALUES ('9', '1', '127.0.0.1', '1511144993');

-- ----------------------------
-- Table structure for migration
-- ----------------------------
DROP TABLE IF EXISTS `migration`;
CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of migration
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '用户名',
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '手机号',
  `status` smallint(6) NOT NULL DEFAULT '10' COMMENT '10为正常，0为封禁',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'admin', '', '$2y$13$HOu4fmKletTcQniqKzAAxuFVtMmXZpCkNHVk4DtB2qmeoxMx.wFfK', null, 'admin@qq.com', '10000000000', '10', '1508640274', '1508640274');
